/*
 * Copyright (C) 2008 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * This package provides the {@link com.google.gson.Gson} class to convert Json to Java and
 * vice-versa.
 *
 * <p>The primary class to use is {@link com.google.gson.Gson} which can be constructed with {@code
 * new Gson()} (using default settings) or by using {@link com.google.gson.GsonBuilder} (to
 * configure various options such as using versioning and so on).
 *
 * @author Inderjeet Singh, Joel Leitch
 */
@com.google.errorprone.annotations.CheckReturnValue
package com.google.gson;
