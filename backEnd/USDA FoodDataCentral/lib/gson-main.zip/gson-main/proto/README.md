# proto

This Maven module contains the source code for a JSON serializer and deserializer for
[Protocol Buffers (protobuf)](https://developers.google.com/protocol-buffers/docs/javatutorial)
messages.

The artifacts created by this module are currently not deployed to Maven Central.
