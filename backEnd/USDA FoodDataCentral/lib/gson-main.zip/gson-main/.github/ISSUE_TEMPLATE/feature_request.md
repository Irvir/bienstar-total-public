---
name: Feature request
about: Request a feature. ⚠️ Gson is in maintenance mode; large feature requests might be rejected.
title: ''
labels: enhancement
assignees: ''

---

# Problem solved by the feature
<!-- Describe which problem the requested feature solves -->


# Feature description
<!-- Describe the feature -->


# Alternatives / workarounds
<!-- Describe alternatives or workarounds in case you are aware of any -->

